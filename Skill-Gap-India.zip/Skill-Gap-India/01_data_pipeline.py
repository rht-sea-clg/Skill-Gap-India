# Databricks notebook source
# Read the table you just created
df = spark.table("workspace.default.job_dataset")

# Check it
display(df)
print("Total rows:", df.count())
print("Columns:", df.columns)

# COMMAND ----------

from pyspark.sql.functions import avg, col

# Save as Bronze Delta Table
df.write.format("delta") \
    .mode("overwrite") \
    .saveAsTable("bronze_skills")

print("Bronze table saved ✅")

# Quick peek at Job Categories
display(df.groupBy("Job_Category").count().orderBy("count", ascending=False))

# COMMAND ----------

from pyspark.sql.functions import col

# Read bronze
bronze = spark.table("bronze_skills")

# Clean — drop nulls, keep only skill columns + category
silver = bronze.dropna()

# Save Silver
silver.write.format("delta") \
    .mode("overwrite") \
    .saveAsTable("silver_skills")

print("Silver table saved ✅")
print("Clean rows:", silver.count())

# COMMAND ----------

# Better gap score — normalize avg_score to 0-100 range
from pyspark.sql.functions import avg, col
import pandas as pd

# Define skill columns
skill_cols = [
    "Skill_Programming", "Skill_DataAnalysis", "Skill_ML_AI", "Skill_Cloud", 
    "Skill_WebDev", "Skill_CyberSec", "Skill_Communication", "Skill_Teamwork", 
    "Skill_ProblemSolving", "Skill_ProjectMgmt", "Skill_Design", 
    "Skill_BusinessAnalysis", "Skill_Statistics", "Skill_Research", 
    "Skill_AI_Programming", "Skill_DevOps", "Skill_MobileDev", "Skill_IoT", 
    "Skill_Language", "Skill_Ethics"
]

avg_scores = spark.table("silver_skills").select(
    [avg(col(c)).alias(c) for c in skill_cols]
).toPandas()

gap_df = avg_scores.melt(var_name="skill", value_name="avg_score")

# Normalize to 0-100
min_val = gap_df["avg_score"].min()
max_val = gap_df["avg_score"].max()
gap_df["gap_score"] = ((gap_df["avg_score"] - min_val) / (max_val - min_val)) * 100
gap_df = gap_df.sort_values("gap_score", ascending=False)

print(gap_df.to_string())

# COMMAND ----------

import mlflow

mlflow.start_run(run_name="SkillGapIndia_v1")

mlflow.log_param("total_skills", 9)
mlflow.log_param("total_rows", 5000)
mlflow.log_metric("highest_gap_score", 100.0)
mlflow.log_metric("avg_gap_score", gap_df["gap_score"].mean())

mlflow.end_run()
print("MLflow tracked ✅")